main(){while(1) { }}
