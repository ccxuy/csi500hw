/*Comment out or undefine CONFIG_VOLATILE
  if you want the shared variable NOT to be
  declared volatile.  When it is not volatile,
  race errors might not appear when optimized
  compilation is used for the racing() function.*/

#define CONFIG_VOLATILE yes
